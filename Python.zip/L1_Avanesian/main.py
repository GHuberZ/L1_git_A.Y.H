from config import MY_FIO
print(f"Hello, {MY_FIO}")

