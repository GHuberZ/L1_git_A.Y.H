# №1

a = int(input())

if a % 2 == 0:
    print("Является")
else:
    print("Неявляется")

# №2

a = int(input())
b = int(input())

if a > b:
    print(a)
elif a < b:
    print(b)
else:
    print("a = b")

# №3

a = int(input())

if a >= 18:
    print("Может")
else:
    print("Неможет")