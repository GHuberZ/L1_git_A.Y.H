# №1

from random import randint

a = 0

for i in range(5):
    b = randint(1, 5)
    a += b

print(a)

# №2

a = [1, 2, 3, 4, 5]

print(max(a))

# №3

a = [1, 2, 2, 3, 4, 4, 5, 6, 6, 6, 7]

aa = unique_numbers = list(dict.fromkeys(numbers))

print(aa)