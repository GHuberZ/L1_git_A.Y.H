# №1

def summ (a, b):
    return a + b
c = summ(5, 3)
print(c)

# №2

def p(a):
    if a <= 1:
        return False
    for i in range(2, int(a**0.5) + 1):
        if a % i == 0:
            return False
    return True
s = p(7)
print(s)

# №3

def sred(a):
    if len(a) == 0:
        return 0
    return sum(a) / len(a)
s = sred([1, 2, 3, 4, 5])
print(s)