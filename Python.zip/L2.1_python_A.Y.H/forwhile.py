# №1

for i in range(1, 10):
print(i)

# №2

a = int(input())

for i in range(1, a):
    print(i)

# №3

sum = 0

for i in range(1, 100):
    while sum != 100:
        sum += 1