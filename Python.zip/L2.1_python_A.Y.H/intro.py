print("Hello, World!")

print(f"Привет, {input()}")