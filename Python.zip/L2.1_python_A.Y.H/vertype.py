print(int(input()) + int(input()))

print("Тип данных:", type(int(input())))

print(f"Вам {int(input())} лет.")