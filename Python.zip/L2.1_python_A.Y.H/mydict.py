# №1

name = input()
firstname = input()
age = int(input())

dict = name, firstname, age

print(dict)

# №2

name = input()
firstname = input()
age = int(input())

dicta = name, firstname, age
dictb = name, age, firstname
dictc = dicta + dictb

print(dictc)

# №3

my_dict = {"name": "aga", "age": 25, "city": "York"}

key_to_check = "age"

if key_to_check in my_dict:
    print(f"Ключ '{key_to_check}' найден в словаре.")
else:
    print(f"Ключ '{key_to_check}' не найден в словаре.")